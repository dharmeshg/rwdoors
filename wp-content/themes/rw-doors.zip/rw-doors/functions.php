<?php

/*------------------------------------*\
	Custom Post Types
\*------------------------------------*/

function create_post_type_html5()
{
    register_post_type('dealers', // Register Custom Post Type
        array(
        'labels' => array(
            'name' => __('Dealers', 'html5blank'), // Rename these to suit
            'singular_name' => __('Dealer', 'html5blank'),
            'add_new' => __('Add New', 'html5blank'),
            'add_new_item' => __('Add New Dealer', 'html5blank'),
            'edit' => __('Edit', 'html5blank'),
            'edit_item' => __('Edit Dealer', 'html5blank'),
            'new_item' => __('New Dealert', 'html5blank'),
            'view' => __('View Dealer', 'html5blank'),
            'view_item' => __('View Dealer', 'html5blank'),
            'search_items' => __('Search Dealer', 'html5blank'),
            'not_found' => __('No Dealers found', 'html5blank'),
            'not_found_in_trash' => __('No Dealers found in Trash', 'html5blank')
        ),
        'public' => true,
        'hierarchical' => true, // Allows your posts to behave like Hierarchy Pages
        'has_archive' => false,
        'supports' => array(
            'title',
            'editor',
			'thumbnail'
        ), // Go to Dashboard Custom HTML5 Blank post for supports
        'can_export' => true // Allows export in Tools > Export
    ));
}

add_action('init', 'create_post_type_html5');

function html5blank_conditional_scripts()
{
	if (is_page_template('page-dealers.php')) {
		wp_register_script('googlemapapi', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyCEcnwUhJpMARyGynm__Li_C2sjMUky2XA&libraries=places', array('jquery'));
		wp_enqueue_script('googlemapapi'); // Enqueue it!
		
		wp_register_script('markerclusterer', 'https://cdnjs.cloudflare.com/ajax/libs/js-marker-clusterer/1.0.0/markerclusterer_compiled.js', array());
		wp_enqueue_script('markerclusterer'); // Enqueue it!

		wp_register_script('googlemap', get_stylesheet_directory_uri() . '/js/googlemap.js', array('jquery'), '1.0.0');
		wp_enqueue_script('googlemap'); // Enqueue it!
	}
	
	if (is_page_template('page-dealer-form.php')) {
		wp_register_script('dealerform', get_stylesheet_directory_uri() . '/js/dealer-form.js', array('jquery'), '1.0.0');
		wp_enqueue_script('dealerform'); // Enqueue it!
	}
	
	if (is_singular('dealers') ) {
		wp_register_script('googlemapapi', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyCEcnwUhJpMARyGynm__Li_C2sjMUky2XA&extension=.js', array('jquery'));
		wp_enqueue_script('googlemapapi'); // Enqueue it!

		wp_register_script('googlemapsingle', get_stylesheet_directory_uri() . '/js/googlemapsingle.js', array('jquery'), '1.0.0');
		wp_enqueue_script('googlemapsingle'); // Enqueue it!

        wp_register_script('dealer-script', get_stylesheet_directory_uri() . '/js/dealer-script.js', array('jquery'), '1.0.0');
        wp_enqueue_script('dealer-script'); // Enqueue it!
	}
}

add_action('wp_print_scripts', 'html5blank_conditional_scripts');