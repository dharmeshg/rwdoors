</div>

<div class="container-fluid top-footer">
	<div class="t-en">
		<h3 class="d-garage">Select a garage door collection:</h3>
		<h3 class="oh-door">Select a commercial door series: </h3>
	</div>
	<div class="t-fr">
		<h3 class="d-garage">Choisissez une collection de portes de garage:</h3>
		<h3 class="oh-door">Sélectionnez une série de portes commerciales:</h3>
	</div>
	<div class="t-es">
		<h3 class="d-garage">Seleccione una colección de puerta de cochera:</h3>
		<h3 class="oh-door">Seleccionar una serie de puertas comerciales:</h3>
	</div>
</div>

		<div id="d-col">
			<div class="container-fluid">
		<?php get_sidebar('footer'); //footer-sidebar ?>
			</div>
		</div>

			<footer class="f-footer" role="contentinfo">

			<div class="container-fluid">
			
				<div id="inner-footer" class="clearfix">
				
		          <div id="widget-footer" class="clearfix row-fluid">
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer1') ) : ?>
		            <?php endif; ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer2') ) : ?>
		            <?php endif; ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer3') ) : ?>
		            <?php endif; ?>
		          </div>


		<div class="f-bottom">

				<div class="if-bottom">

					<div class="l-foot">

					<?php echo do_shortcode( '[widget id="text-32"]' ); ?>
					</div>
				</div>

				<div id="fmenu-mobile">
				<?php echo do_shortcode( '[widget id="ubermenu_navigation_widget-2"]' ); ?>

				<p class="t-en c-right">Copyright © 2017 Richards-Wilcox Canada All Rights Reserved.</p>

				<p class="t-fr c-right">Copyright © 2017 Richards-Wilcox Canada Tous droits réservés.</p>

				<p class="t-es c-right">Copyright © 2017 Richards-Wilcox Canada Tous droits réservés.</p>
			</div>

			<div id="m-foot">
			<nav class="clearfix">
				<?php bones_footer_links(); // Adjust using Menus in Wordpress Admin ?>
		</nav>

			<p class="t-en c-right">Copyright © 2017 Richards-Wilcox Canada All Rights Reserved.</p>

			<p class="t-fr c-right">Copyright © Richards-Wilcox Canada, 2017. Tous droits réservés.</p>

			<p class="t-es c-right">Copyright © 2017 Richards-Wilcox Canada. Todos los derechos reservados.</p>
			</div>
			
			<div class="r-foot">
				<?php do_action('icl_language_selector'); ?>
			</div>
		</div>

		</div>
				

		
				</div> <!-- end #inner-footer -->

		</div> <!-- end #container -->
				
			</footer> <!-- end footer -->
				
		<!--[if lt IE 7 ]>
  			<script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
  			<script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
		<![endif]-->
		
		<?php wp_footer(); // js scripts are inserted using this function ?>

	</body>

</html>