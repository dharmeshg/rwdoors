<!doctype html>  

<!--[if IEMobile 7 ]> <html <?php language_attributes(); ?>class="no-js iem7"> <![endif]-->
<!--[if lt IE 7 ]> <html <?php language_attributes(); ?> class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html <?php language_attributes(); ?> class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html <?php language_attributes(); ?> class="no-js ie8"> <![endif]-->
<!--[if (gte IE 9)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!--><html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->
	
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title><?php wp_title( '|', true, 'right' ); ?></title>
				
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
				
		<!-- media-queries.js (fallback) -->
		<!--[if lt IE 9]>
			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>			
		<![endif]-->

		<!-- html5.js -->
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
  		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">

		<!-- wordpress head functions -->
		<?php wp_head(); ?>
		<!-- end of wordpress head -->

		<!-- theme options from options panel -->
		<?php get_wpbs_theme_options(); ?>

		<!-- typeahead plugin - if top nav search bar enabled -->
		<?php require_once('library/typeahead.php'); ?>

		
		<script type="text/javascript">
			function showImage(imgName, imgText) {
				var curImage = document.getElementById('currentImg');
				var textDiv = document.getElementById('rightText');			
				
				curImage.src = imgName;
				curImage.alt = imgName;
				curImage.title = imgName;
				textDiv.innerHTML = imgText;
			}
			
			function preLoadImages() {
				var tmp = new Array();
				for(var i = 0; i < attributes.length; i++) {
					tmp[i] = new Image();
					tmp[i].src = attributes[i];
				}
			}
		</script>

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600italic,700,300italic,300,700italic' rel='stylesheet' type='text/css'>
				
	</head>
	
	<body <?php body_class(); ?>>
				
		<header role="banner">
		
			<div id="inner-header" class="clearfix">
				
				<div class="navbar navbar-fixed-top">
					<div class="navbar-inner">
						<div class="container-fluid nav-container">

	<div id="top-menu">
		<ul class="t-en">
			<li class="g-top"><a href="/garage-doors/">Residential</a></li>
			<li class="o-top last-child"><a href="/overhead-doors/">Commercial</a></li>
		</ul>

		<ul class="t-fr">
			<li class="g-top"><a href="/fr/garage-doors/">Résidentiel</a></li>
			<li class="o-top last-child"><a href="/fr/overhead-doors/">Commercial</a></li>
		</ul>

		<ul class="t-es">
			<li class="g-top"><a href="/es/garage-doors/">Residencial</a></li>
			<li class="o-top last-child"><a href="/es/overhead-doors/">Comercial </a></li>
		</ul>
	</div>

	<div id="h-wrap">

		<div class="h-left">
	<?php echo do_shortcode( '[widget id="text-110"]' ); ?>

	

			<a class="brand" id="logo" title="<?php echo get_bloginfo('description'); ?>" href="<?php echo home_url(); ?>">
									<?php if(of_get_option('branding_logo','')!='') { ?>
										<img src="<?php echo of_get_option('branding_logo'); ?>" alt="<?php echo get_bloginfo('description'); ?>">
										<?php }
										if(of_get_option('site_name','1')) bloginfo('name'); ?></a>
		</div>			

		<div class="h-right">
							<nav role="navigation">
								
								<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
							        <span class="icon-bar"></span>
							        <span class="icon-bar"></span>
							        <span class="icon-bar"></span>
								</a>
								
								<div class="nav-collapse">
									<?php bones_main_nav(); // Adjust using Menus in Wordpress Admin ?>

									<?php bones_main_nav2(); // Adjust using Menus in Wordpress Admin ?>
								</div>
								
							</nav>

		</div>
	</div>
							
							<?php if(of_get_option('search_bar', '1')) {?>
							<form class="navbar-search pull-right" role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
								<input name="s" id="s" type="text" class="search-query" autocomplete="off" placeholder="<?php _e('Search','bonestheme'); ?>" data-provide="typeahead" data-items="4" data-source='<?php echo $typeahead_data; ?>'>
							</form>
							<?php } ?>
							
						</div> <!-- end .nav-container -->
					</div> <!-- end .navbar-inner -->
				</div> <!-- end .navbar -->

		<div id="mobile-menu">
	<?php echo do_shortcode( '[widget id="ubermenu_navigation_widget-3"]' ); ?>
		</div>

			</div> <!-- end #inner-header -->
		
		</header> <!-- end header -->
		
		<div class="container-fluid">