<?php
/*
Template Name: Dealers
*/
?>

<?php get_header('dealers'); ?>

<?php get_template_part('loop-dealers'); ?>

<?php get_footer('dealers'); ?>