<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Monstroid2
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>

<script type="text/javascript">
			function showImage(imgName, imgText) {
				var curImage = document.getElementById('currentImg');
				var textDiv = document.getElementById('rightText');			
				
				curImage.src = imgName;
				curImage.alt = imgName;
				curImage.title = imgName;
				textDiv.innerHTML = imgText;
			}
			
			function preLoadImages() {
				var tmp = new Array();
				for(var i = 0; i < attributes.length; i++) {
					tmp[i] = new Image();
					tmp[i].src = attributes[i];
				}
			}
		</script>
<style>
.dealers-template-default #primary{left: 0px;    max-width: 100%;    flex: 0px;}
.main_getfree_form .gform_wrapper ul li{    list-style-type: none !important;}

@media only screen and (min-width: 768px) and (max-width:1024px)
{
.tm_pb_builder #tm_builder_outer_content .tm_pb_text_0{display:block !important;}
}
</style>

<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
</head>

<body <?php body_class(); ?>>
<?php monstroid2_get_page_preloader(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'monstroid2' ); ?></a>
	<header id="masthead" <?php monstroid2_header_class(); ?> role="banner">
		<?php monstroid2_ads_header() ?>
		<?php get_template_part( 'template-parts/header/mobile-panel' ); ?>
		<?php get_template_part( 'template-parts/header/top-panel', get_theme_mod( 'header_layout_type' ) ); ?>

		<div <?php monstroid2_header_container_class(); ?> id="for_mobile">
		<?php get_template_part( 'template-parts/header/layout', get_theme_mod( 'header_layout_type' ) ); ?>
		</div><!-- .header-container -->

		<div <?php monstroid2_header_container_class(); ?>>
<div class="container">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 main_header">

<div class="col-lg-4 col-md-3 col-sm-12 col-xs-12 main_header_left text-center paddingnone" id="for_desk">
<!-- <a href="http://www.rwdoors.com/"><img src="http://www.rwdoors.com/wp-content/uploads/2017/06/RW_Logo.png" alt="rwdoors" class="site-link__img"></a> -->
<?php dynamic_sidebar( 'top-logo' ); ?>
</div>

<div class="col-lg-8 col-md-9 col-sm-12 col-xs-12 main_header_right paddingnone">

<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 header_right paddingnone">
<a href="tel:+18006671572">+1 (800) 667-1572</a>
<a href="http://www.rwdoors.com/dealers/">Find A Dealer</a> 
<a class="for_garage" href="http://www.rwdoors.com/select-your-door/beautyshots.html">Select Your Door</a>
<a class="for_overhead" href="http://www.rwdoors.com/architects/">Architects</a>

<div class="sfm-rollback sfm-color1 sfm-theme-none sfm-label-visible sfm-label-metro">
    <div class="sfm-navicon-button x sf_label_default"><div class="sfm-navicon"></div></div>
</div>

</div>
</div>

</div></div>
		</div><!-- .header-container -->

	</header><!-- #masthead -->

	<div id="content" <?php monstroid2_content_class(); ?>>
