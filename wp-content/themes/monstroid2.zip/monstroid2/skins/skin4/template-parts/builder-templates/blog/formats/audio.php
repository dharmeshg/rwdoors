<?php
/**
 * Template for displaying audio post format item content
 *
 *  @package Monstroid2
 */

tm_divi_post_format_content();
